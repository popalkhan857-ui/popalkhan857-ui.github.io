NOOR AHMAD POPAL — PERFUSION EDUCATION WEBSITE

Open index.html in a browser to preview the website.

Next production steps:
1. Add professional photo and verified biography.
2. Add verified certificates/CV.
3. Add article pages in English and Pashto.
4. Add a searchable knowledge base.
5. Connect a domain and professional email.
6. Add references and update dates to every clinical article.
